from .src.intcore import Tsintegrator
from .src.intcore import Tsintegrator1D
from .src.intcore import Tsintegrator2D
